This project is not being actively maintained and there is no one officially offering support or help.

Only PRs are being evaluated (there is no deadline for evaluation).

Read more here: https://github.com/markavespiritu/yii2-user/issues/903
