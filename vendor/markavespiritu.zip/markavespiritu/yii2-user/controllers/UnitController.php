<?php


namespace markavespiritu\user\controllers;

use markavespiritu\user\models\Unit;
use yii\helpers\ArrayHelper;

class UnitController extends \yii\web\Controller
{

    /**
     * Returns all City/Municipalities on a certain Province.
     * @param string           $province     province_c     Province Code
     * @return Json {id:$citymun->citymun_c, name:$citymun->LGU_M}
     */
    public function actionUnitList($office = null, $section = null)
    {
        if(!is_null($office))
        {
            $units = Unit::find()->select(['id','title'])->andWhere(['office_id' => $office]);

            if(!is_null($section))
            {
                $units = $units->andWhere(['section_id' => $section]);
            }else{
                $units = $units->andWhere(['section_id' => null]);
            }

            $units = $units->asArray()->all();

            $arr = [];
            $arr[] = ['id'=>'','text'=>''];

            foreach($units as $unit){
                $arr[] = ['id'=>$unit['id'],'text'=> $unit['title']];
            }
            \Yii::$app->response->format = 'json';
            return $arr;
        }
    }

}


