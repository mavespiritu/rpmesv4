<?php


namespace markavespiritu\user\controllers;

use markavespiritu\user\models\Section;
use yii\helpers\ArrayHelper;

class SectionController extends \yii\web\Controller
{

    /**
     * Returns all City/Municipalities on a certain Province.
     * @param string           $province     province_c     Province Code
     * @return Json {id:$citymun->citymun_c, name:$citymun->LGU_M}
     */
    public function actionSectionList($office)
    {
        $sections = Section::find()->select(['id','title'])->where(['office_id' => $office])->all();
        $arr = [];
        $arr[] = ['id'=>'','text'=>''];
        foreach($sections as $section){
            $arr[] = ['id'=>$section->id,'text'=> $section->title];
        }
        \Yii::$app->response->format = 'json';
        return $arr;
    }

}


