<?php

use yii\db\Schema;
use yii\db\Migration;

class m160127_032449_create_user_info extends Migration
{
    public function up()
    {
       $tables = Yii::$app->db->schema->getTableNames();
        $dbType = $this->db->driverName;
        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
        $tableOptions_mssql = "";
        $tableOptions_pgsql = "";
        $tableOptions_sqlite = "";
        /* MYSQL */
        if (!in_array('user_info', $tables))  { 
        if ($dbType == "mysql") {
            $this->createTable('{{%user_info}}', [
                'user_id' => 'INT(11) NOT NULL AUTO_INCREMENT',
                0 => 'PRIMARY KEY (`user_id`)',
                'EMP_N' => 'INT(11) NULL',
                'LAST_M' => 'VARCHAR(255) NULL',
                'FIRST_M' => 'VARCHAR(255) NULL',
                'MIDDLE_M' => 'VARCHAR(255) NULL',
                'SUFFIX' => 'VARCHAR(255) NULL',
                'BIRTH_D' => 'DATE NOT NULL',
                'SEX_C' => 'VARCHAR(7) NULL',
                'OFFICE_C' => 'INT(2) NULL',
                'SECTION_C' => 'INT(3) NULL',
                'UNIT_C' => 'INT(3) NULL',
                'POSITION_C' => 'VARCHAR(100) NULL',
                'DESIGNATION' => 'VARCHAR(100) NULL',
                'REGION_C' => 'VARCHAR(2) NOT NULL',
                'PROVINCE_C' => 'VARCHAR(2) NULL',
                'CITYMUN_C' => 'VARCHAR(3) NULL',
                'MOBILEPHONE' => 'VARCHAR(20) NULL',
                'LANDPHONE' => 'VARCHAR(20) NULL',
                'FAX_NO' => 'VARCHAR(20) NULL',
                'EMAIL' => 'VARCHAR(100) NULL',
                'PHOTO' => 'VARCHAR(100) NULL',
                'ALTER_EMAIL' => 'VARCHAR(100) NULL',
            ], $tableOptions_mysql);
        }
        }
         
         
        $this->createIndex('idx_OFFICE_C_211_00','user_info','OFFICE_C',0);
        $this->createIndex('idx_PROVINCE_C_211_01','user_info','PROVINCE_C',0);
        $this->createIndex('idx_REGION_C_211_02','user_info','REGION_C',0);
         
        $this->execute('SET foreign_key_checks = 0');
        $this->addForeignKey('fk_tblprovince_2104_00','{{%user_info}}', 'PROVINCE_C', '{{%tblprovince}}', 'province_c', 'CASCADE', 'CASCADE' );
        $this->addForeignKey('fk_tblregion_2104_01','{{%user_info}}', 'REGION_C', '{{%tblregion}}', 'region_c', 'CASCADE', 'CASCADE' );
        $this->addForeignKey('fk_tbloffice_2104_02','{{%user_info}}', 'OFFICE_C', '{{%tbloffice}}', 'id', 'CASCADE', 'CASCADE' );
        $this->addForeignKey('fk_tblsection_2104_02','{{%user_info}}', 'SECTION_C', '{{%tblsection}}', 'id', 'CASCADE', 'CASCADE' );
        $this->addForeignKey('fk_tblunit_2104_02','{{%user_info}}', 'UNIT_C', '{{%tblunit}}', 'id', 'CASCADE', 'CASCADE' );
        $this->addForeignKey('fk_user_2104_03','{{%user_info}}', 'user_id', '{{%user}}', 'id', 'CASCADE', 'CASCADE' );
        $this->execute('SET foreign_key_checks = 1;');
    }

    public function down()
    {
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `user_info`');
        $this->execute('SET foreign_key_checks = 1;');
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
