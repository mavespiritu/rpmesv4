<?php

use yii\db\Migration;
use yii\db\Schema;

class m160928_093111_add_barangay_c extends Migration
{
    public function up()
    {
        $this->addColumn('{{%user_info}}', 'BARANGAY_C', Schema::TYPE_STRING."(3)");

    }

    public function down()
    {
         $this->dropColumn('{{%user_info}}', 'BARANGAY_C');

    }

}
