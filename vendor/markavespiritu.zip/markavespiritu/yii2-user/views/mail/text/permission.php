<?php



/**
 * @var niksko12\user\models\User
 */
?>
<?= Yii::t('user', 'Hello') ?>,

<?= Yii::t('user', 'This is to inform you that your DILG Intranet account permissions have been updated.') ?>

<?= Yii::t('user', '(This is a system-generated message. Please do not reply.)') ?>
