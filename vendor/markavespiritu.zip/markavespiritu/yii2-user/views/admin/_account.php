<?php



use yii\bootstrap\ActiveForm;
use yii\helpers\Html;

/*
 * @var yii\web\View $this
 * @var markavespiritu\user\models\User $user
 */

?>

<?php $this->beginContent('@markavespiritu/user/views/admin/update.php', ['user' => $user]) ?>

<?php $form = ActiveForm::begin([
    'layout' => 'horizontal',
    'enableAjaxValidation'   => true,
    'enableClientValidation' => true,
    'fieldConfig' => [
        'horizontalCssClasses' => [
            'wrapper' => 'col-sm-9',
        ],
    ],
]); ?>

<?= $this->render('_user', 
            ['form'         => $form, 
            'user'          => $user, 
            'userinfo'      => $userinfo, 
            'offices'       => $offices,
]) ?>

<div class="form-group">
    <div class="col-md-12 col-xs-12">
        <?= Html::submitButton(Yii::t('user', 'Update'), ['class' => 'btn btn-block btn-success']) ?>
    </div>
</div>

<?php ActiveForm::end(); ?>

<?php $this->endContent() ?>
