<?php



use markavespiritu\user\models\UserSearch;
use yii\data\ActiveDataProvider;
use yii\grid\GridView;
use yii\helpers\Html;
use yii\jui\DatePicker;
use yii\web\View;
use yii\widgets\Pjax;
use yii\helpers\ArrayHelper;
use kartik\select2\Select2;
use kartik\export\ExportMenu;

/**
 * @var View $this
 * @var ActiveDataProvider $dataProvider
 * @var UserSearch $searchModel
 */

$this->title = Yii::t('user', 'Manage users');
$this->params['breadcrumbs'][] = $this->title;
?>

<?= $this->render('/_alert', [
    'module' => Yii::$app->getModule('user'),
]) ?>

<?= $this->render('/admin/_menu') ?>

<div class="row">
	<div class="col-md-12">
		<div class="pull-right">
		<?php
			if(isset(Yii::$app->modules['gridview'])){
				$gridColumns = [
					[
						'label'=>'Agency',
						'value'=> function ($model){
								return ($model->userinfo->AGENCY_C) ? $model->userinfo->agency->code : '';
						},
					],
					[
						'label'=>'Full Name',
						'value'=> function ($model){
								return $model->userinfo->fullName;
						},
					],
					'username',
					'email:email',
					[
						'attribute' => 'registration_ip',
						'value' => function ($model) {
							return $model->registration_ip == null
								? '<span class="not-set">' . Yii::t('user', '(not set)') . '</span>'
								: $model->registration_ip;
						},
						'format' => 'html',
					],
					[
						'attribute' => 'created_at',
						'value' => function ($model) {
							if (extension_loaded('intl')) {
								return Yii::t('user', '{0, date, YYYY/MM/dd HH:mm}', [$model->created_at]);
							} else {
								return date('Y/m/d G:i:s', $model->created_at);
							}
						},
					],
					[
						'attribute' => 'confirmed_at',
						'header' => Yii::t('user', 'Confirmation'),
						'value' => function ($model) {
							if ($model->isConfirmed) {
								return 'Confirmed';
							} else {
								return 'Not Confirmed';
							}
						},
						'format' => 'raw',
						'visible' => Yii::$app->getModule('user')->enableConfirmation,
					],
					[
						'attribute' => 'blocked_at',
						'header' => Yii::t('user', 'Block status'),
						'value' => function ($model) {
							if ($model->isBlocked) {
								return 'Blocked';
							} else {
								return 'Not Blocked';
							}
						},
						'format' => 'raw',
					],
				];
				//Renders a export dropdown menu
				echo ExportMenu::widget([
					'dataProvider' => $dataProvider,
					'columns' => $gridColumns,
					'exportConfig' => [
						ExportMenu::FORMAT_TEXT => false,
						ExportMenu::FORMAT_PDF => false
					]
				]);
			}
		?>
		</div>
	</div>
</div>
<?php Pjax::begin() ?>

<div class="table-responsive">
<?= GridView::widget([
    'dataProvider' 	=> $dataProvider,
    'filterModel'  	=> $searchModel,
    'layout'  		=> "{items}\n{pager}",
    'columns' => [
		['class' => 'yii\grid\SerialColumn'],
		[
			'label'=>'Agency',
			'attribute'=>'AGENCY_C',
			'value'=> function ($model){
					return ($model->userinfo->AGENCY_C) ? $model->userinfo->agency->code : '';
			},
			'filter' => Select2::widget([
							'model' => $searchModel,
							'attribute' => 'AGENCY_C',
							'data' => ArrayHelper::map($offices, 'id', 'title'),
							'options' => ['placeholder' => '', 'multiple'=>false],
							'pluginOptions' => [
								'allowClear' => true
							],
						]),
			'visible' => true,
		],
		[
			'attribute'=>'keyname',
			'label'=>'Full Name',
			'value'=> function ($model){
					return $model->userinfo->fullName;
			},
		],
        'username',
        'email:email',
        [
            'attribute' => 'registration_ip',
            'value' => function ($model) {
                return $model->registration_ip == null
                    ? '<span class="not-set">' . Yii::t('user', '(not set)') . '</span>'
                    : $model->registration_ip;
            },
            'format' => 'html',
			'visible' => false
        ],
        [
            'attribute' => 'created_at',
            'value' => function ($model) {
                if (extension_loaded('intl')) {
                    return Yii::t('user', '{0, date, YYYY/MM/dd HH:mm}', [$model->created_at]);
                } else {
                    return date('Y/m/d G:i:s', $model->created_at);
                }
            },
            'filter' => DatePicker::widget([
                'model'      => $searchModel,
                'attribute'  => 'created_at',
                'dateFormat' => 'php:Y-m-d',
                'options' => [
                    'class' => 'form-control',
                ],
            ]),
        ],
        [
            'header' => Yii::t('user', 'Has Role?'),
            'value' =>  function ($model) {
                return Html::a($model->hasRole,['/user/admin/assignments','id' => $model->id],['title' => 'Click to view assigned roles and permissions', 'class' => 'btn btn-xs btn-'.(($model->hasRole == 'Yes') ? 'success' : 'danger').' btn-block']);
            },
            'format' => 'raw',
			'visible' => !isset(Yii::$app->modules['user-management']) ? true : false,
        ],
        [
			'attribute' => 'has_role',
            'header' => Yii::t('user', 'Has Role?'),
            'value' =>  function ($model) {
				$value = 'No';
				$btnType = 'default';
				if(!empty($model->intranetUser->authAssignments)){
					$value = 'Yes';
					$btnType = 'info';
				}
                return Html::a($value,['/user-management/user/update-plugin','id' => $model->id],['title' => 'Click to view assigned roles and permissions', 'class' => 'btn btn-xs btn-'.$btnType.' btn-block']);
            },
            'format' => 'raw',
			'visible' => isset(Yii::$app->modules['user-management']) ? true : false,
			'filter' => ['Yes'=>'Yes', 'No'=>'No'],
        ],
        [
            'attribute' => 'confirmed_at',
            'header' => Yii::t('user', 'Confirmation'),
            'value' => function ($model) {
                if ($model->isConfirmed) {
                    return '<div class="text-center"><span class="text-success">' . Yii::t('user', 'Confirmed') . '</span></div>';
                } else {
                    return Html::a(Yii::t('user', 'Confirm'), ['confirm', 'id' => $model->id], [
                        'class' => 'btn btn-xs btn-success btn-block',
                        'data-method' => 'post',
                        'data-confirm' => Yii::t('user', 'Are you sure you want to confirm this user?'),
                    ]);
                }
            },
            'format' => 'raw',
            'visible' => Yii::$app->getModule('user')->enableConfirmation,
			'filter' => ['Yes'=>'Yes', 'No'=>'No'],
        ],
        [
			'attribute' => 'blocked_at',
            'header' => Yii::t('user', 'Block status'),
            'value' => function ($model) {
                if ($model->isBlocked) {
                    return Html::a(Yii::t('user', 'Unblock'), ['block', 'id' => $model->id], [
                        'class' => 'btn btn-xs btn-success btn-block',
                        'data-method' => 'post',
                        'data-confirm' => Yii::t('user', 'Are you sure you want to unblock this user?'),
                    ]);
                } else {
                    return Html::a(Yii::t('user', 'Block'), ['block', 'id' => $model->id], [
                        'class' => 'btn btn-xs btn-danger btn-block',
                        'data-method' => 'post',
                        'data-confirm' => Yii::t('user', 'Are you sure you want to block this user?'),
                    ]);
                }
            },
            'format' => 'raw',
			'filter' => ['Yes'=>'Blocked', 'No'=>'Not Blocked'],
        ],
        [
            'class' => 'yii\grid\ActionColumn',
            'template' => '{resend} {update} {delete}',
			'buttons' => [
				'resend' => function ($url, $model, $key) {
					if(!$model->isConfirmed){
						return Html::a('<span class="glyphicon glyphicon-repeat"></span>', ['resend-confirmation', 'id'=>$model->id], ['data-method' => 'post', 'data-confirm' => Yii::t('user', 'Resending confirmation email. Continue?'), 'title'=>'Resend confirmation email']);
					}
				},
			]
        ],
    ],
]); ?>
</div>
<?php Pjax::end() ?>
