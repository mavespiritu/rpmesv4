<?php

use kartik\select2\Select2;
use dosamigos\datepicker\DatePicker;

/**
 * @var yii\widgets\ActiveForm 		$form
 * @var markavespiritu\user\models\User 	$user
 */

$sectionsurl = \yii\helpers\Url::to(['section/section-list']);
$unitsurl = \yii\helpers\Url::to(['unit/unit-list']);
?>

<h4>User Details</h4>
<div class='row'>
    <div class='col-md-6 col-xs-12'>
        <?= $form->field($userinfo, 'AGENCY_C')->widget(Select2::classname(), [
                'data' => $offices,
                'options' => ['placeholder' => 'Agency','multiple' => false, 'class' => 'agency-select'],
                'pluginOptions' => [
                    'allowClear' => true
                ],
            ]);
        ?>
        <?= $form->field($userinfo, 'POSITION_C')->textInput(); ?>
    </div>
    <div class='col-md-6 col-xs-12'>
        <?= $form->field($userinfo, 'FIRST_M')->textInput(['placeholder'=>'First Name']); ?>

        <?= $form->field($userinfo, 'MIDDLE_M')->textInput(['placeholder'=>'Middle Name']); ?>

        <?= $form->field($userinfo, 'LAST_M')->textInput(['placeholder'=>'Last Name']); ?>
        
        <?= $form->field($userinfo, 'SUFFIX')->textInput(['placeholder'=>'Suffix']); ?>
    </div>
</div>

<hr>
<h4>Account Details</h4>

<div class="row">

    <div class="col-md-6 col-xs-12">
        <?= $form->field($user, 'email')->textInput(['placeholder'=>'Email Address']); ?>

        <?= $form->field($user, 'username')->textInput(['placeholder'=>'Username']); ?>

        <?= $form->field($user, 'password')->passwordInput() ?>
    </div>
</div>


