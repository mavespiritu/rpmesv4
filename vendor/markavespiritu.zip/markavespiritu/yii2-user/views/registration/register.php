<?php



use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\web\JsExpression;
use dosamigos\datepicker\DatePicker;
use frontend\assets\AppAsset;

/**
 * @var yii\web\View              $this
 * @var markavespiritu\user\models\User $user
 * @var markavespiritu\user\Module      $module
 */

$this->title = Yii::t('user', 'Sign up');
$this->params['breadcrumbs'][] = $this->title;

$asset = AppAsset::register($this);
?>
<div class="row">
    <div class="col-md-8 col-xs-12">
        <div class="fill"></div>
    </div>
    <div class="col-md-4 col-xs-12">
        <div class="row">
            <div class="col-md-1 col-xs-12"></div>
            <div class="col-md-10 col-xs-12">
            <br>
            <h4>Registration Form</h4>
            <br>
            <h5>Fill-out the form to create an account</h5>
                <?php $form = ActiveForm::begin([
                    'id'                     => 'registration-form',
                    'enableAjaxValidation'   => true,
                    'enableClientValidation' => false,
                ]); ?>
                <p class="text-right" style="font-size: 10px;">* Required fields</p>
                <h4>User Details</h4>
                <br>
                <?= $form->field($model, 'AGENCY_C')->widget(Select2::classname(), [
                        'data' => $offices,
                        'options' => ['placeholder' => 'Select Agency','multiple' => false, 'class' => 'agency-select'],
                        'pluginOptions' => [
                            'allowClear' => true
                        ],
                    ])->label('Agency *');
                ?>
                <div class="row">
                    <div class="col-md-6 col-xs-12">
                        <?= $form->field($model, 'FIRST_M')->textInput()->label('First Name *'); ?>   
                    </div>
                    <div class="col-md-6 col-xs-12">
                        <?= $form->field($model, 'LAST_M')->textInput()->label('Last Name *'); ?>
                    </div>
                </div>

                <?= $form->field($model, 'POSITION_C')->textInput()->label('Position *'); ?>

                <hr style="opacity: 0.5;">

                <h4>Account Details</h4>
                <br>

                <?= $form->field($model, 'email')->textInput()->label('Email Address *'); ?>

                <?= $form->field($model, 'username')->textInput()->label('Username *'); ?>

                <?php if ($module->enableGeneratingPassword == false): ?>
                    <?= $form->field($model, 'password')->passwordInput()->label('Password *'); ?>
                <?php endif ?>

                <?= $form->field($model, 'TERM')->checkBox(['label' => 'I represent and warrant that I authorize NEDA and/or any of its agents/representatives to collect and process personal and sensitive personal information to be utilized solely on the use of the eRPMES.', 'data-size'=>'small', 'id'=>'active']) ?>

                <?= Html::submitButton(Yii::t('user', 'Sign up'), ['class' => 'btn btn-success btn-block']) ?>

                <?php ActiveForm::end(); ?>
        <br>
        <p class="text-center">
            <?= Html::a(Yii::t('user', 'Already registered? Sign in!'), ['/user/security/login']) ?>
        </p>
        </div>
        <div class="col-md-1 col-xs-12"></div>
    </div>
</div>

<style>
.centered {
    text-align: center;
    font-size: 0;
}
.centered > div {
   float: none;
   display: inline-block;
   text-align: left;
}

.fill {
    display: flex;
    justify-content: center;
    align-items: center;
    overflow: hidden;
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100vh;
    width: 100%;
    background: url(<?= $asset->baseUrl.'/images/neda.jpg' ?>) repeat-y center fixed;
    background-size: cover;
}

.content{
    margin: 0 !important;
    padding: 0 !important;
}
</style>
