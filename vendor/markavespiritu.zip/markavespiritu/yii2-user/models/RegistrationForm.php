<?php



namespace markavespiritu\user\models;

use markavespiritu\user\traits\ModuleTrait;
use Yii;
use yii\base\Model;

/**
 * Registration form collects user input on registration process, validates it and creates new User model.
 *
 * @author Dmitry Erofeev <dmeroff@gmail.com>
 */
class RegistrationForm extends Model
{
    use ModuleTrait;
    /**
     * @var string User email address
     */
    public $email;

    /**
     * @var string Username
     */
    public $username;

    /**
     * @var string Password
     */
    public $password;

    /**
     * @var string First Name
     */
    public $FIRST_M;

    /**
     * @var string Last Name
     */
    public $LAST_M;

    /**
     * @var string Middle Name
     */
    public $MIDDLE_M;

    /**
     * @var string Extension Name
     */
    public $SUFFIX;

    /**
     * @var string Office Code
     */
    public $OFFICE_C;

    /**
     * @var string Section Code
     */
    public $SECTION_C;

    /**
     * @var string Unit Code
     */
    public $UNIT_C;
    
    /**
     * @var string Unit Code
     */
    public $POSITION_C;

    /**
     * @var string Unit Code
     */
    public $AGENCY_C;

    /**
     * @var string Unit Code
     */
    public $TERM;

    /**
     * @var string Employee Number
     */
    public $EMP_N;




    /**
     * @inheritdoc
     */
    public function rules()
    {
        $user = $this->module->modelMap['User'];
        $userinfo = $this->module->modelMap['UserInfo'];

        return [
            // username rules
            'usernameLength'   => ['username', 'string', 'min' => 3, 'max' => 255],
            'usernameTrim'     => ['username', 'filter', 'filter' => 'trim'],
            'usernamePattern'  => ['username', 'match', 'pattern' => $user::$usernameRegexp],
            'usernameRequired' => ['username', 'required'],
            'usernameUnique'   => [
                'username',
                'unique',
                'targetClass' => $user,
                'message' => Yii::t('user', 'This username has already been taken')
            ],
            // email rules
            'emailTrim'     => ['email', 'filter', 'filter' => 'trim'],
            'emailRequired' => ['email', 'required'],
            'emailPattern'  => ['email', 'email'],
            'emailUnique'   => [
                'email',
                'unique',
                'targetClass' => $user,
                'message' => Yii::t('user', 'This email address has already been taken')
            ],
            'employeeUnique'   => [
                'EMP_N',
                'unique',
                'targetClass' => $userinfo,
                'message' => Yii::t('user', 'This Employee ID has already been taken')
            ],
            [['LAST_M', 'FIRST_M', 'AGENCY_C', 'POSITION_C'], 'required'],
            ['TERM', 'required', 'requiredValue' => 1, 'message' => 'You need to agree to terms and conditions'],
            [['AGENCY_C'], 'integer'],
            [['EMP_N'], 'safe'],
            [['LAST_M', 'FIRST_M', 'MIDDLE_M', 'SUFFIX'], 'string', 'max' => 255],
            // password rules
            'passwordRequired' => ['password', 'required', 'skipOnEmpty' => $this->module->enableGeneratingPassword],
            'passwordLength'   => ['password', 'string', 'min' => 6],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'email'    => Yii::t('user', 'Email'),
            'username' => Yii::t('user', 'Username'),
            'password' => Yii::t('user', 'Password'),
            'EMP_N' => 'Employee ID No.',
            'LAST_M' => 'Last Name',
            'FIRST_M' => 'First Name',
            'MIDDLE_M' => 'Middle Name',
            'SUFFIX' => 'Suffix',
            'OFFICE_C' => 'Division',
            'AGENCY_C' => 'Agency',
            'SECTION_C' => 'Section',
            'UNIT_C' => 'Unit',
            'POSITION_C' => 'Position',
            'TERM' => 'Term',
        ];
    }

    /**
     * @inheritdoc
     */
    public function formName()
    {
        return 'register-form';
    }

    /**
     * Registers a new user account. If registration was successful it will set flash message.
     *
     * @return bool
     */
    public function register()
    {
        if (!$this->validate()) {
            return false;
        }

        /** @var User $user */
        $user = Yii::createObject(User::className());
        $user->setScenario('register');
        $this->loadAttributes($user);
        $userinfo = Yii::createObject(UserInfo::className());
        /*if($this->OFFICE_C==""){
            $this->setScenario('GeneralApplication');
            $userinfo->setScenario('GeneralApplication');
        }else if($this->OFFICE_C=="1"){
            $this->setScenario('RegionalOffice');
            $userinfo->setScenario('RegionalOffice');
        }else if($this->OFFICE_C=="2"){
            $this->setScenario('ProvincialOffice');
            $userinfo->setScenario('ProvincialOffice');
        }else if($this->OFFICE_C=="3"){
            $this->setScenario('CitymunOffice');
            $userinfo->setScenario('CitymunOffice');
        }else if($this->OFFICE_C=="4"){
            $this->setScenario('CitymunOffice');
            $userinfo->setScenario('CitymunOffice');
        }else if($this->OFFICE_C=="5"){
            $this->setScenario('CentralOffice');
            $userinfo->setScenario('CentralOffice');
        }*/
        $this->loadUserInfoAttributes($userinfo);
        $user->_userinfo = $userinfo ;

        if (!$user->register()) {
            return false;
        }

        Yii::$app->session->setFlash(
            'info',
            Yii::t('user', 'Your account has been created. Contact Administrator to ask for permissions and privileges')
        );

        return true;
    }


    /**
     * Loads attributes to the user model. You should override this method if you are going to add new fields to the
     * registration form. You can read more in special guide.
     *
     * By default this method set all attributes of this model to the attributes of User model, so you should properly
     * configure safe attributes of your User model.
     *
     * @param User $user
     */
    protected function loadAttributes(User $user)
    {
        $user->setAttributes($this->attributes);
    }

    protected function loadUserInfoAttributes(UserInfo $userinfo){
        $userinfo->setAttributes($this->attributes);
    }
}
