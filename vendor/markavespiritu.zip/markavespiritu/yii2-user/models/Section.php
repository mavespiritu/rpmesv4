<?php

namespace markavespiritu\user\models;

use Yii;

/**
 * This is the model class for table "section".
 *
 * @property int $id
 * @property int $office_id
 * @property string $title
 *
 * @property Event[] $events
 * @property Office $office
 * @property Unit[] $units
 */
class Section extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'tblsection';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['office_id', 'title', 'abbreviation'], 'required'],
            [['office_id'], 'integer'],
            [['title', 'abbreviation'], 'string', 'max' => 250],
            [['office_id'], 'exist', 'skipOnError' => true, 'targetClass' => Office::className(), 'targetAttribute' => ['office_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'office_id' => 'Office ID',
            'title' => 'Title',
            'abbreviation' => 'Abbreviation'
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOffice()
    {
        return $this->hasOne(Office::className(), ['id' => 'office_id']);
    }

    public function getOfficeName()
    {
        return $this->office ? $this->office->name : '-';
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUnits()
    {
        return $this->hasMany(Unit::className(), ['section_id' => 'id']);
    }
}
