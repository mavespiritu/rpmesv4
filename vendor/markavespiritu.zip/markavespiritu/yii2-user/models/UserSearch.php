<?php



namespace markavespiritu\user\models;

use markavespiritu\user\Finder;
use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;

/**
 * UserSearch represents the model behind the search form about User.
 */
class UserSearch extends Model
{
    /** @var string */
    public $username;

    /** @var string */
    public $email;

    /** @var int */
    public $created_at;

    /** @var string */
    public $registration_ip;

	public $keyname;

    /** @var Finder */
    protected $finder;
	
	public $AGENCY_C;

	public $confirmed_at;

	public $blocked_at;

	public $has_role;

    /**
     * @param Finder $finder
     * @param array  $config
     */
    public function __construct(Finder $finder, $config = [])
    {
        $this->finder = $finder;
        parent::__construct($config);
    }

    /** @inheritdoc */
    public function rules()
    {
        return [
            'fieldsSafe' => [['username', 'email', 'registration_ip', 'created_at', 'AGENCY_C', 'keyname', 'confirmed_at', 'blocked_at', 'has_role'], 'safe'],
            'createdDefault' => ['created_at', 'default', 'value' => null],
        ];
    }

    /** @inheritdoc */
    public function attributeLabels()
    {
        return [
            'username'        => Yii::t('user', 'Username'),
            'email'           => Yii::t('user', 'Email'),
            'created_at'      => Yii::t('user', 'Registration time'),
            'registration_ip' => Yii::t('user', 'Registration ip'),
            'AGENCY_C' 		  => Yii::t('user', 'Agency'),
            'confirmed_at' 	  => Yii::t('user', 'Confirmation'),
            'has_role' 	      => Yii::t('user', 'Has Role?'),
        ];
    }

    /**
     * @param $params
     *
     * @return ActiveDataProvider
     */
    public function search($params, $additionalParams = [])
    {
        $query = $this->finder->getUserQuery();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);
		$query->joinWith('userinfo');
		if(isset($additionalParams['and'])){
			foreach($additionalParams['and'] as $additionalParams):
				$query->andWhere($additionalParams);
			endforeach;
		}
		if(isset($additionalParams['or'])){
			foreach($additionalParams['or'] as $additionalParams):
				$query->orWhere($additionalParams);
			endforeach;
		}
        if (!($this->load($params) && $this->validate())) {
            return $dataProvider;
        }

        if ($this->created_at !== null) {
            $date = strtotime($this->created_at);
            $query->andFilterWhere(['between', 'created_at', $date, $date + 3600 * 24]);
        }
		
        if ($this->confirmed_at == 'Yes') {
            $query->andFilterWhere(['>=', 'confirmed_at', 1]);
        }else if ($this->confirmed_at == 'No') {
            $query->andWhere(['confirmed_at' => null]);
        }
		
        if ($this->blocked_at == 'Yes') {
            $query->andFilterWhere(['>=', 'blocked_at', 1]);
        }else if ($this->blocked_at == 'No') {
            $query->andWhere(['blocked_at' => null]);
        }
				
        $query->andFilterWhere(['like', 'username', $this->username])
            ->andFilterWhere(['like', 'user.email', $this->email])
            ->andFilterWhere(['AGENCY_C' => $this->AGENCY_C])
            ->andFilterWhere(['registration_ip' => $this->registration_ip]);
		
		if(isset(Yii::$app->modules['user-management'])){
			$userIds = \common\modules\usermanagement\models\AuthAssignment::find()->select('user_id');
			if($this->has_role == 'Yes'){
				$query->andWhere(['id'=>$userIds]);
			}else if($this->has_role == 'No'){
				$query->andWhere(['NOT IN', 'id', $userIds]);
			}
		}
		
		
		$nameArray = explode(' ', $this->keyname);
		foreach($nameArray as $name):
			$query->andFilterWhere(['or', ['like', 'FIRST_M', $name], ['like', 'MIDDLE_M', $name], ['like', 'LAST_M', $name]]);
			endforeach;
        return $dataProvider;
    }
}
