<?php

namespace markavespiritu\user\models;

use Yii;
use common\modules\rpmes\models\Agency;
/**
 * This is the model class for table "user_info".
 *
 * @property integer $user_id
 * @property integer $EMP_N
 * @property string $LAST_M
 * @property string $FIRST_M
 * @property string $MIDDLE_M
 * @property string $SUFFIX
 * @property string $BIRTH_D
 * @property string $SEX_C
 * @property integer $OFFICE_C
 * @property integer $DIVISION_C
 * @property integer $SECTION_C
 * @property integer $POSITION_C
 * @property integer $DESIGNATION
 * @property string $REGION_C
 * @property string $PROVINCE_C
 * @property string $CITYMUN_C
 * @property string $MOBILEPHONE
 * @property string $LANDPHONE
 * @property string $FAX_NO
 * @property string $EMAIL
 * @property string $PHOTO
 * @property string $ALTER_EMAIL
 *
 * @property Tbldesignation $dESIGNATION
 * @property Tbldilgposition $pOSITIONC
 * @property Tbloffice $oFFICEC
 * @property Tblprovince $pROVINCEC
 * @property Tblregion $rEGIONC
 * @property User $user
 */
class UserInfo extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'user_info';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['LAST_M', 'FIRST_M', 'AGENCY_C', 'POSITION_C', 'TERM'], 'required'],
            [['AGENCY_C'], 'integer'],
            [['EMP_N'], 'safe'],
            /* [['FIRST_M'], 'match', 'pattern' => '/^[a-zA-Z\s-Ñ]+$/','message' => 'First Name can only contain letters'],
            [['MIDDLE_M'], 'match', 'pattern' => '/^[a-zA-Z\s-Ñ]+$/','message' => 'Middle Name can only contain letters'],
            [['LAST_M'], 'match', 'pattern' => '/^[a-zA-Z\s-Ñ]+$/','message' => 'Last Name can only contain letters'],
            [['SUFFIX'], 'match', 'pattern' => '/^[a-zA-Z\s.]+$/','message' => 'Extension Name can only contain letters'], */
            [['LAST_M', 'FIRST_M', 'MIDDLE_M', 'SUFFIX'], 'string', 'max' => 255],
            [['EMP_N'], 'unique'],
            [['EMAIL', 'PHOTO', 'ALTER_EMAIL','EMP_N'], 'string', 'max' => 100],
            [['EMAIL','ALTER_EMAIL'],'email'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'user_id' => 'User ID',
            'EMP_N' => 'Employee ID No.*',
            'LAST_M' => 'Last Name',
            'FIRST_M' => 'First Name',
            'MIDDLE_M' => 'Middle Name',
            'SUFFIX' => 'Extension Name',
            'BIRTH_D' => 'Birth Date',
            'SEX_C' => 'Sex',
            'OFFICE_C' => 'Division',
            'SECTION_C' => 'Section',
            'UNIT_C' => 'Unit',
            'POSITION_C' => 'Position',
            'DESIGNATION' => 'Designation',
            'REGION_C' => 'Region',
            'PROVINCE_C' => 'Province',
            'CITYMUN_C' => 'City/Municipality',
            'BARANGAY_C' => 'Barangay',
            'AGENCY_C' => 'Agency',
            'MOBILEPHONE' => 'Mobilephone',
            'LANDPHONE' => 'Landphone',
            'FAX_NO' => 'Fax',
            'EMAIL' => 'Email',
            'PHOTO' => 'Photo',
            'ALTER_EMAIL' => 'Alter  Email',
            'TERM' => 'Term'
        ];
    }


    /**
     * @return Full name of User
     */

    public function getFullName(){
        return $this->FIRST_M." ".$this->MIDDLE_M." ".$this->LAST_M." ".$this->SUFFIX;
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOffice()
    {
        return $this->hasOne(Office::className(), ['id' => 'OFFICE_C']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSection()
    {
        return $this->hasOne(Section::className(), ['id' => 'SECTION_C']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUnit()
    {
        return $this->hasOne(Unit::className(), ['id' => 'UNIT_C']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProvince()
    {
        return $this->hasOne(Province::className(), ['PROVINCE_C' => 'PROVINCE_C']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRegion()
    {
        return $this->hasOne(Region::className(), ['REGION_C' => 'REGION_C']);
    }
	
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCitymun()
    {
        return $this->hasOne(Citymun::className(), ['PROVINCE_C' => 'PROVINCE_C', 'CITYMUN_C' => 'CITYMUN_C']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBarangay()
    {
        return $this->hasOne(Barangay::className(), ['PROVINCE_C' => 'PROVINCE_C', 'CITYMUN_C' => 'CITYMUN_C', 'BARANGAY_C' => 'BARANGAY_C']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAgency()
    {
        return $this->hasOne(Agency::className(), ['id' => 'AGENCY_C']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }
}
