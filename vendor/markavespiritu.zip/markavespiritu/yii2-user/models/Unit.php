<?php

namespace markavespiritu\user\models;

use Yii;

/**
 * This is the model class for table "unit".
 *
 * @property int $id
 * @property int $office_id
 * @property int $section_id
 * @property string $title
 *
 * @property Event[] $events
 * @property Office $office
 * @property Section $section
 */
class Unit extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'tblunit';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['office_id', 'title', 'abbreviation'], 'required'],
            [['office_id', 'section_id'], 'integer'],
            [['title', 'abbreviation'], 'string', 'max' => 250],
            [['office_id'], 'exist', 'skipOnError' => true, 'targetClass' => Office::className(), 'targetAttribute' => ['office_id' => 'id']],
            [['section_id'], 'exist', 'skipOnError' => true, 'targetClass' => Section::className(), 'targetAttribute' => ['section_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'office_id' => 'Office',
            'section_id' => 'Section',
            'title' => 'Title',
            'abbreviation' => 'Abbreviation'
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getEvents()
    {
        return $this->hasMany(Event::className(), ['unit_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOffice()
    {
        return $this->hasOne(Office::className(), ['id' => 'office_id']);
    }

    public function getOfficeName()
    {
        return $this->office ? $this->office->name : '-';
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSection()
    {
        return $this->hasOne(Section::className(), ['id' => 'section_id']);
    }

    public function getSectionName()
    {
        return $this->section ? $this->section->title : '-';
    }
}
