Change Log: `yii2-sortable-input`
=================================

## Version 1.2.1

**Date:** 29-Aug-2018

- (bug #12): Correct sortable input plugin for the latest `html5sortable` release.
- Add github contribution and PR/issue log templates.
- Fix composer settings
- Update copyright year to current.
- Reorganize source code in `src` directory.

## Version 1.2.0

**Date:** 29-Jan-2015

- (enh #1): Plugin enhancement to update parent keys for connected sortables.

## Version 1.1.0

**Date:** 10-Nov-2014

- Set dependency on Krajee base components
- Set release to stable

## Version 1.0.0

**Date:** 01-Aug-2014

- Initial release
- PSR4 alias change