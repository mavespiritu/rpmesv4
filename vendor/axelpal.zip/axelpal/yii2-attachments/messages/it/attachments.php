<?php
/**
 * Translated to italian by Lorenzo Milesi <maxxer@yetopen.it>
 */

return [
    'The model cannot be empty.' => 'Il modello non può essere vuoto.',
    'The behavior FileBehavior has not been attached to the model.' => 'Il behavior FileBehavior non è stato associato al modello.',
    'File name' => 'Nome file'
];
