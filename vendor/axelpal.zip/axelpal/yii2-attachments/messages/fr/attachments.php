<?php
/**
 * Translated to French by MarsuBoss
 */
return [
    'The model cannot be empty.' => 'Le modèle ne peut pas être vide',
    'The behavior FileBehavior has not been attached to the model.' => 'Le comportement FileBehavior n\'a pas été attaché au modèle.',
    'File name' => 'Nom de fichier'
];
