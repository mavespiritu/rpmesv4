<?php
/**
 * Created by PhpStorm.
 * User: Алимжан
 * Date: 02.02.2015
 * Time: 12:22
 */

return [
    'The model cannot be empty.' => 'Модель не может быть пустой.',
    'The behavior FileBehavior has not been attached to the model.' => 'Поведение FileBehavior не привязано к модели.',
    'File name' => 'Название файла'
];